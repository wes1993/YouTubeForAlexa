# -*- coding: utf-8 -*-

__version__ = "10.4.0"

if __name__ == "__main__":
    print(__version__)
